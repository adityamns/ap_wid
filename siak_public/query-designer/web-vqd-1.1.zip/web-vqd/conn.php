<?php 

$username = "root";     // put your username here
$password = "root";     // put your password here

$dbc_info_sch= mysqli_connect("localhost",$username,$password,"information_schema");
$dbc=$dbc_info_sch;
?>

