pwd
coffee -bwc *.coffee 

