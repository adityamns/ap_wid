
$(function() {
  return $('body').append("<div class='breadcrumbs-menu'>  <a href='/..'> Home </a>	> <span class='current' > Demo </span></div>");
});
